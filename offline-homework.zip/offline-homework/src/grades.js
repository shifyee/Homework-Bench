import {kv} from './docs.js';
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const letter=p=>p>=90?'A':p>=80?'B':p>=70?'C':p>=60?'D':'F';
export async function mountGrades(root){
  let rows=(await kv.get('grades'))||[];
  root.innerHTML=`<div class="row"><input type="file" id="gf" accept=".csv"><span class="dim">CSV columns: course,assignment,score,max</span></div>
  <div class="row"><input id="gc" placeholder="Course"><input id="ga" placeholder="Assignment"><input id="gsc" type="number" placeholder="Score" style="width:90px"><input id="gm" type="number" placeholder="Out of" style="width:90px"><button id="gadd">Add</button><button id="gclr">Clear all</button></div><div id="gv"></div>`;
  const $=s=>root.querySelector(s),save=()=>kv.set('grades',rows);
  const draw=()=>{
    if(!rows.length){$('#gv').innerHTML='<p class="dim">No grades yet. Import a CSV or add one above.</p>';return}
    const by={};for(const r of rows){const c=by[r.c]??={s:0,m:0,a:[]};c.s+=r.s;c.m+=r.m;c.a.push(r)}
    const tot=Object.values(by).reduce((t,c)=>({s:t.s+c.s,m:t.m+c.m}),{s:0,m:0}),op=tot.m?tot.s/tot.m*100:0;
    $('#gv').innerHTML=`<div class="c"><h3><span>Overall</span><span>${op.toFixed(1)}% ${letter(op)}</span></h3><div class="bar"><i style="width:${Math.min(100,op)}%"></i></div></div>`+
      Object.entries(by).map(([n,c])=>{const p=c.m?c.s/c.m*100:0;
        return `<div class="c"><h3><span>${esc(n)}</span><span>${p.toFixed(1)}% ${letter(p)}</span></h3><div class="bar"><i style="width:${Math.min(100,p)}%"></i></div>
        ${c.a.map(a=>{const q=a.m?a.s/a.m*100:0;return `<div class="row dim" style="margin-top:6px"><span style="flex:1">${esc(a.a)}</span><span>${a.s}/${a.m}</span><div class="bar" style="width:120px"><i style="width:${Math.min(100,q)}%"></i></div></div>`}).join('')}</div>`}).join('');
  };
  $('#gf').onchange=async e=>{const f=e.target.files[0];if(!f)return;
    for(const l of (await f.text()).split(/\r?\n/)){const [c,a,s,m]=l.split(',').map(x=>x.trim());
      if(c&&Number.isFinite(+s)&&+m>0&&s!=='')rows.push({c,a:a||'-',s:+s,m:+m})} // header and bad rows are skipped, never guessed
    await save();draw();e.target.value=''};
  $('#gadd').onclick=async()=>{const s=+$('#gsc').value,m=+$('#gm').value;if(!$('#gc').value||!(m>0)||!Number.isFinite(s))return;
    rows.push({c:$('#gc').value,a:$('#ga').value||'-',s,m});await save();draw()};
  $('#gclr').onclick=async()=>{if(confirm('Delete all grades?')){rows=[];await save();draw()}};
  draw();
}
