import {CreateWebWorkerMLCEngine,prebuiltAppConfig} from '@mlc-ai/web-llm';
let eng,wk;
// Only small models; f16 builds need half the memory of f32 so prefer them when the GPU supports it.
export async function models(){
  const a=await navigator.gpu?.requestAdapter?.();
  if(!a)return null;
  const q=a.features.has('shader-f16')?'q4f16':'q4f32';
  return prebuiltAppConfig.model_list
    .filter(m=>m.model_id.includes(q)&&/deepseek|Qwen2\.5-(0\.5|1\.5)B-Instruct|Llama-3\.2-1B/i.test(m.model_id))
    .sort((x,y)=>(x.vram_required_MB||0)-(y.vram_required_MB||0));
}
export const ready=()=>!!eng;
export async function unload(){try{await eng?.unload()}catch{}wk?.terminate();eng=wk=null}
export async function load(id,onProgress){
  await unload();
  await navigator.storage?.persist?.(); // stops the browser evicting the weights
  wk=new Worker(new URL('./worker.js',import.meta.url),{type:'module'});
  // IndexedDB cache streams shards one by one; the default Cache API path is what stalls at ~90% for many people.
  const appConfig={...prebuiltAppConfig,useIndexedDBCache:true};
  try{eng=await CreateWebWorkerMLCEngine(wk,id,{appConfig,initProgressCallback:onProgress},{context_window_size:2048});}
  catch(e){await unload();throw e}
}
export async function* stream(messages){
  const s=await eng.chat.completions.create({messages,stream:true,max_tokens:700,temperature:.3});
  for await(const c of s)yield c.choices[0]?.delta?.content||'';
}
export const stop=()=>eng?.interruptGenerate();
