import './style.css';
import {registerSW} from 'virtual:pwa-register';
import * as ai from './ai.js';
import {importFile,exportPDF,exportPPTX,exportDOC,exportTXT,kv} from './docs.js';
import {mountPhoto} from './photo.js';
import {mountGrades} from './grades.js';
registerSW({immediate:true});
const $=s=>document.querySelector(s),all=s=>document.querySelectorAll(s),st=t=>$('#st').textContent=t;

all('nav button').forEach(b=>b.onclick=()=>{
  all('nav button').forEach(x=>x.classList.toggle('on',x===b));
  all('main section').forEach(s=>s.hidden=s.id!==b.dataset.t)});

// ---- AI: nothing loads until you tap Load, and only one model is ever resident
const clean=t=>t.replace(/<think>[\s\S]*?<\/think>/g,'').replace(/<think>[\s\S]*$/,'(thinking…)').trim();
async function run(messages,el){
  if(!ai.ready()){el.textContent='Load the AI first (top bar).';return ''}
  let t='';el.textContent='';
  try{for await(const c of ai.stream(messages)){t+=c;el.textContent=clean(t)}}
  catch(e){el.textContent='AI error: '+e.message}
  return clean(t);
}
ai.models().then(async l=>{
  if(!l){st('No WebGPU here: AI is off, everything else works.');$('#load').disabled=true;return}
  l.forEach(m=>$('#model').add(new Option(`${m.model_id.replace('-MLC','')} (${((m.vram_required_MB||0)/1024).toFixed(1)} GB)`,m.model_id)));
  const saved=await kv.get('model');
  $('#model').value=l.some(m=>m.model_id===saved)?saved:(l.find(m=>/deepseek/i.test(m.model_id)&&m.vram_required_MB<3000)||l[0]).model_id;
}).catch(()=>st('Could not read GPU info.'));
$('#load').onclick=async()=>{
  const id=$('#model').value;if(!id)return;
  $('#load').disabled=true;$('#prog').hidden=false;
  try{await ai.load(id,p=>{$('#prog').value=p.progress||0;st(p.text.slice(0,60))});
    kv.set('model',id);st('AI ready (offline)');$('#unload').hidden=false}
  catch(e){st('Load failed: '+e.message)}
  $('#prog').hidden=true;$('#load').disabled=false;
};
$('#unload').onclick=async()=>{await ai.unload();$('#unload').hidden=true;st('AI unloaded, memory freed')};
$('#stop').onclick=ai.stop;
addEventListener('pagehide',()=>ai.unload());

// ---- Documents
const ed=$('#ed');let tm,last='';
kv.get('doc').then(v=>ed.value=v||'');
ed.oninput=()=>{clearTimeout(tm);tm=setTimeout(()=>kv.set('doc',ed.value),400)};
const imp=(input,set)=>input.onchange=async e=>{const f=e.target.files[0];if(!f)return;st('Reading '+f.name+'…');
  try{set(await importFile(f));st('')}catch(x){st(x.message)}e.target.value=''};
imp($('#imp'),t=>{ed.value=t;kv.set('doc',t)});
imp($('#mimp'),t=>$('#mp').value=t.slice(0,1500));
all('[data-x]').forEach(b=>b.onclick=()=>({pdf:exportPDF,pptx:exportPPTX,doc:exportDOC,txt:exportTXT})[b.dataset.x](ed.value,'homework'));
$('#ask').onclick=async()=>{ // 2048-token window: send a slice, not the whole file
  const sel=ed.value.slice(ed.selectionStart,ed.selectionEnd)||ed.value;
  last=await run([{role:'system',content:'You help a student with homework. Be concise.'},{role:'user',content:`Document:\n${sel.slice(0,3500)}\n\nQuestion: ${$('#q').value}`}],$('#out'))};
$('#ins').onclick=()=>{ed.setRangeText('\n'+last+'\n',ed.selectionEnd,ed.selectionEnd,'end');ed.dispatchEvent(new Event('input'))};

// ---- Math check (DeltaMath has no export, so problems come in by paste or file)
const mrun=(sys,tail)=>run([{role:'system',content:sys},{role:'user',content:`Problem:\n${$('#mp').value.slice(0,1500)}\n\nStudent work:\n${$('#mw').value.slice(0,1500)}\n\n${tail}`}],$('#mo'));
$('#grade').onclick=()=>mrun('You are a strict math teacher. Check every step. Reply with: VERDICT (CORRECT, PARTIAL or INCORRECT), the first wrong step if any, then the correct final answer. Be brief.','Grade this.');
$('#hint').onclick=()=>mrun('You are a math tutor. Give one hint only. Never reveal the final answer.','Give a hint.');
$('#solve').onclick=()=>mrun('You are a math tutor. Solve step by step and put the final answer on the last line.','Solve it.');

mountPhoto($('#photo'));mountGrades($('#grades'));
