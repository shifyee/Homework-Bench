# Homework Bench (offline PWA)

Documents (PDF / Word / PowerPoint in, PDF / PPTX / Word / TXT out), math checking with a local AI, photo editor, grade charts. After one online visit it all runs offline.

## Deploy free on Cloudflare Pages
1. Push this folder to a GitHub repo.
2. Cloudflare dashboard > Workers & Pages > Create > Pages > Connect to Git > pick the repo.
3. Build command `npm run build`, output directory `dist`, env var `NODE_VERSION=20`.
4. Open the `*.pages.dev` URL once while online, tap **Load AI** (one-time model download), then "Install app" / Add to Home Screen.

## Why it should stop crashing
- Model runs in a Web Worker, so the page itself stays light.
- Only models of roughly 0.5-3 GB are offered; f16 builds are picked when the GPU supports them.
- Context is capped at 2048 tokens and replies at 700.
- Weights are cached in IndexedDB (not Cache API) and storage is marked persistent.
- Nothing loads until you tap Load AI; Unload AI frees the memory.
- If it still dies, pick a smaller model in the dropdown and close other tabs.
