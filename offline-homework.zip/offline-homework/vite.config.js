import {defineConfig} from 'vite';
import {VitePWA} from 'vite-plugin-pwa';
export default defineConfig({
  build:{target:'es2022'},
  worker:{format:'es'},
  plugins:[VitePWA({
    registerType:'autoUpdate',
    // precache the whole app shell (JS/wasm/worker) so it boots with zero network
    workbox:{globPatterns:['**/*.{js,mjs,css,html,svg,png,wasm}'],maximumFileSizeToCacheInBytes:15*1024*1024},
    manifest:{name:'Offline Homework',short_name:'HW',display:'standalone',background_color:'#eef2f7',theme_color:'#14213d',
      icons:[{src:'icon.svg',sizes:'any',type:'image/svg+xml',purpose:'any'}]}
  })]
});
